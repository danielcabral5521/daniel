DG WHISKERIA V1

1. Instale Node.js e VS Code.
2. Crie um projeto Firebase.
3. Substitua os dados em src/firebase/config.js.
4. No terminal:
   npm install
   npm run dev
5. Para publicar:
   npm run build
   firebase deploy