export default function App() {
  const whatsapp = () => {
    const msg = encodeURIComponent(
      'Olá! Tenho interesse em produtos da DG Whiskeria.'
    );
    window.open('https://wa.me/5521999999999?text=' + msg, '_blank');
  };

  return (
    <div style={{padding:'20px'}}>
      <h1>DG Whiskeria</h1>

      <h2>Produtos</h2>

      <div>
        <h3>Jack Daniel's 1L</h3>
        <p>R$ 129,90</p>
        <button onClick={whatsapp}>Comprar</button>
      </div>
    </div>
  );
}